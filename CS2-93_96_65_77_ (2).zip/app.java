import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.awt.Color;
class firstWindow extends Frame implements ActionListener
{
    public TextField name,pass;
    public Button b1,b2,b3,b4;
    public firstWindow()
    {
       setLayout(new FlowLayout());
        this.setLayout(null);
       setBounds(100,100,400,600);
       Color formColor = new Color(14, 188, 182);
       setBackground(formColor);
       Label n1=new Label("***Welcome***",Label.CENTER);
       Label n2=new Label("--Select One--",Label.CENTER);
      b1=new Button("Employee");
      b2=new Button("Admin");
      this.add(n1);
      this.add(n2);
      this.add(b1);
      this.add(b2);
      n1.setBounds(170,90,90,60);
      n2.setBounds(160,150,90,60);
      b1.setBounds(80,260,90,40);
      b2.setBounds(180,260,90,40);
        
      b1.addActionListener(this);
      b2.addActionListener(this);
     }

    
      
      public void actionPerformed(ActionEvent e){
     
      if(e.getSource()== b1){
       
        new secandWindow().setVisible(true);
        this.dispose();


     }
      if(e.getSource()== b2){
       
        new  EmLogint().setVisible(true);
        this.dispose();


     }
      

     }
   }
     
    class secandWindow extends Frame implements ActionListener
    {
    
    Button b1,b2,b3;
    secandWindow()
    {
      setLayout(null);
        setBounds(100,100,400,600);
         Color formColor = new Color(14, 188, 182);
         setBackground(formColor);
       Label n1=new Label("***Welcome***",Label.CENTER);
       
      b1=new Button("Login");
      b2=new Button("Register");
      b3=new Button("Back");
      this.add(n1);
      
      this.add(b1);
      this.add(b2);
      this.add(b3);
      n1.setBounds(150,90,90,60);
      
      b1.setBounds(80,260,90,40);
      b2.setBounds(180,260,90,40);
      b3.setBounds(130,310,90,40);
      b1.addActionListener(this);
      b2.addActionListener(this);
      b3.addActionListener(this);

     }

        public void actionPerformed(ActionEvent e){
     
      if(e.getSource()== b1){
       
        new Login().setVisible(true);
        this.dispose();


     }
      if(e.getSource()== b2){
       
        new Resister().setVisible(true);
        this.dispose();


     }
     if(e.getSource()==b3){
       
        new  firstWindow().setVisible(true);
        this.dispose();


     }
      

     }

        

}
   class Resister extends Frame implements ActionListener
{
    TextField name,pass;
    Button b1,b2;
    Resister()
    {
        
        setLayout(null);
        setBounds(100,100,400,600);
        Color formColor = new Color(14, 188, 182);
       setBackground(formColor);
        Label n=new Label("Name:",Label.CENTER);
        Label p=new Label("Id:",Label.CENTER);
        
        name=new TextField(20);
        pass=new TextField(20);
        
        b1=new Button("Register me");
        b2=new Button("Cancel");
        this.add(n);
        this.add(name);
        this.add(p);
        this.add(pass);
        
        this.add(b1);
        this.add(b2);
        n.setBounds(70,90,90,60);
        p.setBounds(70,130,90,60);
        
        name.setBounds(200,100,90,20);
        pass.setBounds(200,140,90,20);
        
        b1.setBounds(100,260,80,40);
        b2.setBounds(190,260,70,40);
        b1.addActionListener(this);
        b2.addActionListener(this);
 
    }
     public void actionPerformed(ActionEvent e){
     
      if(e.getSource()== b1){
       
        String v1=name.getText();
   
        String v2=pass.getText();

         try{
           Class.forName("com.mysql.jdbc.Driver");
        
         Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/emlog", "root", "aaa");
 
          Statement st=con.createStatement();

           int i=st.executeUpdate("insert into empt(name,id) values('"+v1+"','"+v2+"')");
 
          JOptionPane.showMessageDialog(null,"Data is inserted successfully");

        }

        catch(Exception ex){

        System.out.println(ex);
  
       }
  
     }
     
      if(e.getSource()== b2){
       
        new secandWindow().setVisible(true);
        this.dispose();


     }
      

     } 


}
   
   class Login extends Frame implements ActionListener
{
   
    TextField name,pass;
    Button b1,b2;
    Login()
    {
        
        setLayout(null);
        setBounds(100,100,400,600);
        Color formColor = new Color(14, 188, 182);
       setBackground(formColor);
        
        Label n=new Label("Name",Label.CENTER);
        Label p=new Label("Id:",Label.CENTER);
        
        name=new TextField(20);
        pass=new TextField(20);
        
        b1=new Button("Submit");
        b2=new Button("Cancel");
        this.add(n);
        this.add(name);
        this.add(p);
        this.add(pass);
        
        this.add(b1);
        this.add(b2);
        n.setBounds(70,90,90,60);
        p.setBounds(70,130,90,60);
        
        name.setBounds(200,100,90,20);
        pass.setBounds(200,140,90,20);
        
        b1.setBounds(100,260,70,40);
        b2.setBounds(180,260,70,40);
        b1.addActionListener(this);
        b2.addActionListener(this);
 
    }
     public void actionPerformed(ActionEvent e){
     

   

      if(e.getSource()== b1){
         
       String v1=name.getText();
   
       String v2=pass.getText();

      
      try{
           Class.forName("com.mysql.jdbc.Driver");
        
         Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/emlog", "root", "aaa");
         
         PreparedStatement p = null;
        ResultSet rs = null;
        
        try {
 
            // SQL command data stored in String datatype
            String sql = "select * from empt";
            p = con.prepareStatement(sql);
            rs = p.executeQuery();
 
            // Printing ID, name, email of customers
            // of the SQL command above
            System.out.println("name\t\tname\t\tId");
 
            // Condition check
            while (rs.next()) {
 
                
                String name = rs.getString("name");
                String id = rs.getString("id");

                
                if(v1.equals(name) && v2.equals(id)){

                  try{
           Class.forName("com.mysql.jdbc.Driver");
        
         Connection cont = DriverManager.getConnection("jdbc:mysql://localhost:3306/mdb", "root", "aaa");
         
         PreparedStatement pt = null;
        ResultSet rst = null;
        
        try {
 
            // SQL command data stored in String datatype
            String sqlt = "select * from mdbt";
            pt = cont.prepareStatement(sqlt);
            rst = pt.executeQuery();
 
            // Printing ID, name, email of customers
            // of the SQL command above
            System.out.println("\t\tname\t\tId\t\tovertime\t\bonus\t\tnetpay");
 
            // Condition check
            while (rst.next()) {
 
                
                String namet = rst.getString("name");
                String idt = rst.getString("id");
                String overtime = rst.getString("overtime");
                String bonus= rst.getString("bonus");
                String netpay = rst.getString("netpay");

                
                System.out.println( "\t\t" + namet
                                   + "\t\t" + idt + "\t\t" + overtime+ "\t\t" + bonus + "\t\t" +netpay);
                
                

            }
        }
      catch (SQLException a) {
 
            // Print exception pop-up on screen
            System.out.println(a);
        }
          

        }

        catch(Exception ex){

        System.out.println(ex);
  
       }
    }
         
             }
                
                

            }
        
      catch (SQLException a) {
 
            // Print exception pop-up on screen
            System.out.println(a);
        }
          

        }

        catch(Exception ex){

        System.out.println(ex);
  
       }
  
       
      }
      if(e.getSource()== b2){
       
        new secandWindow().setVisible(true);
        this.dispose();


     }

      
     }


}
  

class EmLogint extends Frame  implements ActionListener
{
    TextField nt1,nt2,nt3,nt4,nt5;
    Button b1,b2;
    EmLogint()
    {
        setLayout(null);
        setBounds(100,100,500,600);
        Color formColor = new Color(14, 188, 182);
       setBackground(formColor);
        setLayout(new FlowLayout());
        this.setLayout(null);
        Label n1=new Label("Name:",Label.CENTER);
        Label n2=new Label("Id:",Label.CENTER);
        Label n3=new Label("Overtime:",Label.CENTER);
        Label n4=new Label("Bonus:",Label.CENTER);
        Label n5=new Label("Netpay:",Label.CENTER);
        
        nt1=new TextField(20);
        nt2=new TextField(20);
        nt3=new TextField(20);
        nt4=new TextField(20);
        nt5=new TextField(20);
        
        b1=new Button("submit");
        b2=new Button("cancel");
        this.add(n1);
        this.add(nt1);
        this.add(n2);
        this.add(nt2);
        this.add(n3);
        this.add(nt3);
        this.add(n4);
        this.add(nt4);
        this.add(n5);
        this.add(nt5);
        this.add(b1);
        this.add(b2);
        n1.setBounds(70,90,90,60);
        n2.setBounds(70,140,90,60);
        n3.setBounds(70,190,90,60);
        n4.setBounds(70,230,90,60);
        n5.setBounds(70,270,90,60);
        
        nt1.setBounds(200,100,90,20);
        nt2.setBounds(200,150,90,20);
        nt3.setBounds(200,200,90,20);
        nt4.setBounds(200,240,90,20);
        nt5.setBounds(200,280,90,20);
        


        b1.setBounds(100,340,70,40);
        b2.setBounds(180,340,70,40);
       b1.addActionListener(this);
        b2.addActionListener(this);
        
 
    }  
   public void actionPerformed(ActionEvent e){
      
      if(e.getSource()== b1){
       
        String v1=nt1.getText();
        String v2=nt2.getText();
        String v3=nt3.getText();
        String v4=nt4.getText();
        String v5=nt5.getText();
        
        
       
       
       
         try{
           Class.forName("com.mysql.jdbc.Driver");
        
   Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mdb", "root", "aaa");
 
          Statement st=con.createStatement();

           int i=st.executeUpdate("insert into mdbt(name,id,overtime,bonus,netpay) values('"+v1+"','"+v2+"','"+v3+"','"+v4+"','"+v5+"')");
 
          JOptionPane.showMessageDialog(null,"Data is inserted successfully");

        }

        catch(Exception ex){

        System.out.println(ex);
  
       }
  
     }


     
      if(e.getSource()== b2){
       
        new firstWindow().setVisible(true);
        this.dispose();


     }
      

     }
}
     
 
 




 class app{

     public static void main(String args[])
    {
        firstWindow ml=new firstWindow();
    
        ml.setVisible(true);
        
 
    }
}
